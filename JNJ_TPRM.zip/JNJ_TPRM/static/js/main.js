const move = () =>{
var elem=document.getElementsByClassName("mybar")
var width=0;
var id = setInterval(frame,30)

function frame(){
if(width>=100){
    clearInterval(id);
}
else{
    width++;
    for(var x=0;x<elem.length;x++){
        elem[x].style.width = width + "%";
        document.getElementById("value").innerHTML=width + "%";
        document.getElementById("value1").innerHTML=width + "%";
        }
    
}

}
}
