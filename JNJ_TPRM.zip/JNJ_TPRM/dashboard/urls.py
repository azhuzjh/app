from django.urls import path
from . import views

urlpatterns=[
    path("index",views.index,name="index"),
    path("checkingrisk",views.checkingrisk,name="checkingrisk"),
    path("Existing_vendor",views.Existing_vendor,name="Existing_vendor"),
    path("search_vendor",views.Search_vendor,name="search_vendor"),
    path("viewpdf",views.pdf,name="viewpdf"),
    path("filter_vendor",views.filter_vendor,name="filter_vendor"),
    path("filter_vendor_csv",views.filter_vendor_csv,name="filter_vendor_csv"),
    path("search_multi_vendor",views.search_multi_vendor,name="search_multi_vendor"),
    path("filter_multi__vendor_csv",views.filter_multi__vendor_csv,name="filter_multi__vendor_csv"),


]