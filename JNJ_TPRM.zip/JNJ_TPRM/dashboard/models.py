from email.policy import default
from django.db import models

class Vendor(models.Model):
    vendor_name=models.CharField(max_length=100,null=False)
    service_category=models.CharField(max_length=100,null=False)
    final_risk_score=models.FloatField(default=0.0)
    tier_by_poc=models.IntegerField(default=0)

    def __str__(self):
        return "%s" %(self.vendor_name)

