from django.shortcuts import render
from django.http import HttpResponse
from . models import Vendor
from . pdf import html2pdf
import os
import pandas as pd
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


base_path=os.path.abspath(os.path.dirname(__name__)) + "/dashboard/"

residual_df = pd.read_csv(str(os.path.abspath(os.path.dirname(__name__))) + "/dashboard/Final Risk Table 3.0.csv")



# Helper Function

def getVendor(vendor_name):
    """Helper function to get the vendor names using string match"""
    user_String_Vendor = vendor_name # get user string input

    listed = residual_df['Supplier parent'].unique().tolist()

    result_Vendors = [n for n in listed if user_String_Vendor.lower() in str(n).lower()]      

    if (len(result_Vendors)==0):
        response_Vendors = {'status': 'no record found'} # response
    else:       
        num_result_Vendors = len(result_Vendors)
        print("Bot: we found %s records for you" %num_result_Vendors)   
        response_Vendors = {'Vendor_Name': result_Vendors} # response
    
    return response_Vendors # output VendorNames

# Actual view starts from here


def index(request):
    return render(request,"dashboard/base.html")

def checkingrisk(request):
    return render(request,"dashboard/checkingrisk.html")

def Existing_vendor(request):
    return render(request,"dashboard/Existing_vendor.html")

def Search_vendor(request):
    return render(request,"dashboard/Search_vendor.html") 

def filter_vendor(request):
    if 'vendor_name' in request.GET:
        vendor_name=request.GET.get('vendor_name')
        response=getVendor(vendor_name)
        print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$",response)
        result=response['Vendor_Name']
        context={
            'result':result
        }
        print(context)
        return render(request,"dashboard/search_vendor_csv.html",context)
    return render(request,"dashboard/Search_vendor.html")
        
def filter_vendor_csv(request):
    if request.method=="POST":
        vendor=request.POST['vendor']
        read=pd.read_csv(base_path+"Final Risk Table 3.0.csv")
        vendors_list=read[read['Supplier parent']==vendor].to_dict('records')
        context ={
            'vendor':vendor,
            'vendors_list':vendors_list,
        }
        return render(request,"dashboard/view_vendor_csv.html",context)
    return render(request,"dashboard/search_vendor_csv.html")




def get_risk_score(vendor_or_asset, risk_metric, typ):
    """Helper function to get risk score of a vendor or asset based on risk metric"""
    risk_score = "N/A"
    
    if typ == "inherent":
        pre_risk_row = pre_calc_risk_df.loc[pre_calc_risk_df[vendor_name_col] == vendor_or_asset]
    elif typ == "residual":
        pre_risk_row = residual_df.loc[residual_df['name'] == vendor_or_asset]

    if len(pre_risk_row.index)!=0:
        risk_score = pre_risk_row[risk_metric].iloc[0]
    
    return risk_score  
   
def predictionDetails(request):

    vendor="No Vendor Selected"
    spend_quartile_pre = "N/A"
    concentration_score_pre = "N/A"
    criticality_level_pre = "N/A"
    spend_cr_normalized_pre = "N/A"
    notional_risk_normalized_pre = "N/A"
    business_disruption_pre = "N/A"
    consumer_impact_pre = "N/A"
    business_risk_pre = "N/A"
    data_risk_pre = "N/A"
    cyber_risk_pre = "N/A"
    tech_risk_pre = "N/A"
    inherent_risk_pre = "N/A"
    sector_dict = "N/A"
    category_dict = "N/A"

    if 'vendor-name' in request.GET:
        vendor = request.GET.get('vendor-name')
        
        # pre calculated spend quartile
        spend_quartile_pre = get_risk_score(vendor, 'Spending Quartile', 'inherent')
        print('Spend Quartile Pre: ', spend_quartile_pre) 
        
        if spend_quartile_pre == "N/A":
            vendor = "Suppler Parent Not Found"
            concentration_score_pre = "N/A"
            criticality_level_pre = "N/A"
            spend_cr_normalized_pre = "N/A"
            notional_risk_normalized_pre = "N/A"
            business_disruption_pre = "N/A"
            consumer_impact_pre = "N/A"
            business_risk_pre = "N/A"
            data_risk_pre = "N/A"
            cyber_risk_pre = "N/A"
            tech_risk_pre = "N/A"
            inherent_risk_pre = "N/A"    
            sector_dict = "N/A"
            category_dict = "N/A"
        
        else:
            # pre calculated concentration risks
            concentration_scores_pre = get_risk_score(vendor, 'Concentration risks', 'inherent')
            print("CR Scores Pre: ", concentration_scores_pre)
            
            # pre calculated concentration risk normalized
            concentration_score_pre = get_risk_score(vendor, 'Calculated Concentration Risk Normalized', 'inherent')
            print("CR Normalized Score Pre: ", concentration_score_pre)
            
            # pre calculated criticality level
            criticality_level_pre = get_risk_score(vendor, 'CL Metric Normalized', 'inherent')
            print('CL Pre: ', criticality_level_pre)
            
            # pre calculated Spend * CR Normalized
            spend_cr_normalized_pre = get_risk_score(vendor, 'Spend x CR Normalized', 'inherent')
            print('Spend * CR Normalized Pre: ', spend_cr_normalized_pre)

            # pre calculated Calculated Notional Risk Normalized
            notional_risk_normalized_pre = get_risk_score(vendor, 'Calculated Notional Risk Normalized', 'inherent')
            print('Calculated Notional Risk Normalized Pre: ', notional_risk_normalized_pre)

            # pre calculated business disruption
            business_disruption_pre = get_risk_score(vendor, 'Business Disruption', 'inherent')
            print('Business Disruption Pre: ', business_disruption_pre)

            # pre calculated Consumer Impact
            consumer_impact_pre = get_risk_score(vendor, 'Consumer Impact', 'inherent')
            print('Consumer Impact Pre: ', consumer_impact_pre)

            # pre calculated business risk
            business_risk_pre = get_risk_score(vendor, 'Business Risk', 'inherent')
            print('Business Risk Pre: ', business_risk_pre)

            # pre calculated data risk
            data_risk_pre = get_risk_score(vendor, 'Data Risk Normalized', 'inherent')
            print('Data Risk Pre: ', data_risk_pre)
            
            # pre calculated cyber risk
            cyber_risk_pre = get_risk_score(vendor, 'Cyber Risk Normalized', 'inherent')
            print('Cyber Risk Pre: ', cyber_risk_pre)

            # pre calculated tech risk
            tech_risk_pre = get_risk_score(vendor, 'Tech Risk Normalized', 'inherent')
            print('Tech Risk Pre: ', tech_risk_pre)

            # pre calculated inherent risk
            inherent_risk_pre = get_risk_score(vendor, 'Inherent Risk Prediction', 'inherent')
            print('Inherent Risk Pre: ', inherent_risk_pre)            

            pre_category_sector_rows = pre_category_sector_risk_df.loc[pre_category_sector_risk_df[vendor_name_col] == vendor]
            print(pre_category_sector_rows)
            # pre_category_sector_rows = pre_category_sector_rows.dropna()
            # print(pre_category_sector_rows)

            sector_dict = {}
            category_dict = {}

            for sector, value in zip(pre_category_sector_rows['Sector'].value_counts().index.tolist(),pre_category_sector_rows['Sector'].value_counts()):
                sector_rows = pre_category_sector_rows.loc[pre_category_sector_rows['Sector'] == sector]
                sector_dict[sector] = []
                sector_dict[sector].append(sector_rows['Business Risk'].sum()/value)
                sector_dict[sector].append(sector_average_risk_df.loc[sector_average_risk_df['Sector'] == sector].iloc[0,1])
                # total_sector_risk = sum(sector_dict[sector])
                # sector_dict[sector][0] = round((sector_dict[sector][0]/total_sector_risk)*100)
                # sector_dict[sector][1] = round((sector_dict[sector][1]/total_sector_risk)*100)

            for category, value in zip(pre_category_sector_rows['Category'].value_counts().index.tolist(),pre_category_sector_rows['Category'].value_counts()):
                category_rows = pre_category_sector_rows.loc[pre_category_sector_rows['Category'] == category]
                category_dict[category] = []
                category_dict[category].append(category_rows['Business Risk'].sum()/value)
                category_dict[category].append(category_average_risk_df.loc[category_average_risk_df['Category'] == category].iloc[0,1])
                # total_category_risk = sum(category_dict[category])
                # category_dict[category][0] = round((category_dict[category][0]/total_category_risk)*100)
                # category_dict[category][1] = round((category_dict[category][1]/total_category_risk)*100)

            print("\nSector_dict: ",sector_dict)
            print("Category_dict: ",category_dict)
            print("Range_dict: ",range_df)
            print()

    # pass this content dictionary to the results.html template
    content = {
        "vendorname": vendor,
        "risk_scores": {
            "Spend Quartile": spend_quartile_pre,
            "Concentration Risk": concentration_score_pre,
            "Criticality Level": criticality_level_pre,
            "Spend * CR Normalized": spend_cr_normalized_pre,
            "Notional Risk": notional_risk_normalized_pre,
            "Business Disruption": business_disruption_pre,
            "Consumer Impact": consumer_impact_pre,
            "Business Risk": business_risk_pre,
            "Data Risk": data_risk_pre,
            "Cyber Risk": cyber_risk_pre,
            "Tech Risk": tech_risk_pre,
            "Inherent Risk": inherent_risk_pre,
        },
        'sector_data': sector_dict,
        'category_data': category_dict,
        'range_data': range_df,
    }

    return render(request, 'jnjapp/results.html', content)






























def search_multi_vendor(request,vendor_count=100):
    read=pd.read_csv(base_path+"Final Risk Table 3.0.csv")
    vendors_list = read[read['Business Risk'].notna()].sort_values('Business Risk', ascending=False).head(100).to_dict('records')
    # to paginate long list of records into desired number of vendors per page
    paginator = Paginator(vendors_list, vendor_count)
    print(paginator.page(1).object_list)
    page = request.GET.get('page',1)
    try:
        vendors = paginator.page(page)
    except PageNotAnInteger:
        vendors = paginator.page(1)
    except EmptyPage:
        vendors = paginator.page(paginator.num_pages)
    
    context = {
        "vendors": vendors,
        'pvl':'active'
    }
    print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$4",vendors)

    return render(request,"dashboard/search_multi_vendor.html",context)
    
    



def filter_multi__vendor_csv(request):
    if request.method=="POST":
        sector=request.POST['sector']
        Family=request.POST['Family']
        read=pd.read_csv(base_path+"Final Risk Table 3.0.csv")
        read_sector=read[read['Sector']==sector].to_dict('records')
        read_Family=read[read['Family']==Family].to_dict('records')
        context ={
            'read_sector':read_sector,
            'read_Family':read_Family,
        }
        print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@",read_sector)
        return render(request,"dashboard/view_multi_vendor_csv.html",context)
    return render(request,"dashboard/search_multi_vendor.html")
       
def pdf(request):
    vendor_name=request.session['vendor_name']
    vendor=Vendor.objects.filter(vendor_name__icontains=vendor_name)
    context={
        'vendor':vendor
    }
    pdf=html2pdf("dashboard/view_vendor.html",context)
    return HttpResponse(pdf,content_type="application/pdf")    




































































# def view_vendor_csv(request):
#     read=pd.read_csv(base_path+"Final Risk Table 3.0.csv")
#     vendors_list = read[read['Business Risk'].notna()].sort_values('Business Risk', ascending=False).head(100).to_dict('records')
#     context={
#         'vendors_list':vendors_list
#     }
#     return render(request,"dashboard/view_vendor_csv.html",context)

# def view_multi_vendor_csv(request):
#     read=pd.read_csv(base_path+"Final Risk Table 3.0.csv")
#     vendors_list = read[read['Business Risk'].notna()].sort_values('Business Risk', ascending=False).head(100).to_dict('records')
#     context={
#         'vendors_list':vendors_list
#     }
#     print("###################################",context)
#     return render(request,"dashboard/view_multi_vendor_csv.html",context)

# def Search_vendor_dropdown(request):
#     read=pd.read_csv(base_path+"Final Risk Table 3.0.csv")
#     vendors_list = read[read['Business Risk'].notna()].sort_values('Business Risk', ascending=False).head(100).to_dict('records')
#     context={
#         'vendors_list':vendors_list
#     }
#     print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&",context)
#     return render(request,"dashboard/search_vendor_csv.html",context) 

# def view_vendor(request):
#     vendor=Vendor.objects.all()
#     context={
#         'vendor':vendor
#     }
#     return render(request,"dashboard/view_vendor.html",context)


# def filter_vendor(request):
#     if request.method=="POST":
#         vendor_name=request.POST['vendor_name']
#         vendor=Vendor.objects.all()
#         request.session['vendor_name']=vendor_name
#         if vendor_name:
#             vendor=vendor.filter(vendor_name__icontains=vendor_name)
#         context={
#             'vendor':vendor
#         }
#         return render(request,"dashboard/view_vendor.html",context)
    
#     return render(request,"dashboard/Search_vendor.html")
    
# def pdf(request):
#     vendor_name=request.session['vendor_name']
#     vendor=Vendor.objects.filter(vendor_name__icontains=vendor_name)
#     context={
#         'vendor':vendor
#     }
#     pdf=html2pdf("dashboard/view_vendor_csv.html",context)
#     return HttpResponse(pdf,content_type="application/pdf")