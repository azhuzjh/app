from cmath import nan
from http.client import responses
import re
from unicodedata import category
from django.shortcuts import render
from django.http.response import HttpResponseRedirect
from django.urls import reverse
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.platypus import Table

import plotly.graph_objects as go
import matplotlib.pyplot as plt

from .header import getHeader
from .body import getBody, getPage2Body, getPage3Body, getPreBody
from .footer import getFooter

import pandas as pd
import numpy as np
import os
import json
import math

import io
from django.http import FileResponse

base_path = str(os.path.abspath(os.path.dirname(__name__))) + "/capone_app/"
base_path1 = str(os.path.abspath(os.path.dirname(__name__)))

risk_df = pd.read_csv(str(os.path.abspath(os.path.dirname(__name__))) + "/capone_app/Final Risk Table 2.0.csv")
service_category_df = pd.read_csv(str(os.path.abspath(os.path.dirname(__name__))) + "/capone_app/Concentration Risk by Service Category.csv")

# Helper Functions

def getVendor(vendor_name):
    """Helper function to get the vendor names using string match"""
    vendor_name_col = "18 Digit ID"
    user_String_Vendor = vendor_name # get user string input

    listed = risk_df[vendor_name_col].unique().tolist() # match the string input with vendor names in dataset

    result_Vendors = [n for n in listed if user_String_Vendor.lower() in str(n).lower()]

    if (len(result_Vendors)==0):
        response_Vendors = {'status': 'no record found'} # response
    else:       
        num_result_Vendors = len(result_Vendors)
        print("Bot: we found %s records for you" %num_result_Vendors)   
        response_Vendors = {'Vendor_Name': result_Vendors,'status':'records found'} # response
    
    json_Vendors =json.dumps(response_Vendors) # json formatted
    return json_Vendors # output VendorNames

def get_col_value(vendor, col_name):
    """Helper function to get column value of a vendor or asset based on column name"""
    col_value = ""
    
    vendor_row = risk_df.loc[risk_df["18 Digit ID"] == vendor]

    if len(vendor_row.index)!=0:
        col_value = vendor_row[col_name].iloc[0]
    
    return col_value


# Views

def index(request):
    content = {'i':'active'}
    return render(request, 'capone_app/index.html', content)

def overall_landscape(request):

    service_category_list = list(service_category_df['Service Category w/ Software LOB 1'])

    if request.method == 'POST':
        print(request.POST)
        if 'category' in request.POST:
            category = request.POST.get('category')
            if category:
                return HttpResponseRedirect(reverse('capone_app:category_summary',args=[category]))

    content = {
        'ol':'active',
        'service_category_list':service_category_list,
    }
    return render(request, 'capone_app/overall_landscape.html', content)

def category_summary(request, category):

    service_cate = category
    sub = risk_df[risk_df['Max Risk Service Category w/ Software LOB 1'] == service_cate]
    size = []
    level = [1, 2, 3, 4]
    names = []

    for i in level:
        print(i)
        sub_s = sub[sub["Tier by POC"] == i]
        if len(sub_s.index) != 0: 
            size.append(len(sub_s.index))
            names.append(i)
        print("tier: ", i, "size: ", size)
    
    # create data
    names = ["Tier " + str(i) for i in names]
    print("Names:",names)
    # Create a circle at the center of the plot
    my_circle = plt.Circle( (0,0), 0.7, color='white')
    plt.title(service_cate + "  [count: " + str(sum(size))+ "]" )
    # Custom wedges
    plt.pie(size, labels=names, wedgeprops = { 'linewidth' : 7, 'edgecolor' : 'white' })
    p = plt.gcf()
    p.gca().add_artist(my_circle)
    p.savefig(base_path1+'/static/assets/img/category_summary.png')
    plt.clf()
    plt.cla()
    plt.close()
    
    df_sub = sub[['operational risk normalized',
    'business risk normalized',
    'technology risk normalized',
    'compliance risk normalized',
    'data risk normalized', 
                'Concentration Risk Normalized', 
                'Final Risk Score']]
    vals, names, xs = [],[],[]
    for i, col in enumerate(df_sub.columns):
        vals.append(df_sub[col].values)
        names.append(col)
        xs.append(np.random.normal(i + 1, 0.05, df_sub[col].values.shape[0]))  # adds jitter to the data points - can be adjusted
    plt.boxplot(vals, labels=names)
    palette = ['purple', 'g', 'b', 'y', 'gold', 'black', 'red']
    for x, val, c in zip(xs, vals, palette):
        plt.scatter(x, val, alpha=0.3, color=c)
    plt.xticks(rotation = 90)

    plt.savefig(base_path1+'/static/assets/img/category_summary_boxplot.png', bbox_inches='tight')
    plt.clf()
    plt.cla()
    plt.close()

    content = {
        'ol':'active',
        'category':category
    }

    return render(request, 'capone_app/category_summary.html', content)

def search_vendor(request):
    content = {'sv':'active'}
    return render(request, 'capone_app/search_vendor.html', content)

def vendor_page(request):

    vendor_names = False

    if 'vendor' in request.GET:
        vendor = request.GET.get('vendor')
        if vendor != '' and not vendor.isspace():
            response = json.loads(getVendor(vendor))
            print("response is here")
            print(response)
            if(response['status']!='no record found'):
                vendor_names = response['Vendor_Name']
                print("vendor_names are")
                print(vendor_names)
        else:
            return HttpResponseRedirect(reverse('capone_app:search_vendor'))

    content = {
        "show_vendors": vendor_names,
        'sv':'active'
    }

    return render(request, 'capone_app/vendor_page.html',content)

def vendor_report(request):

    vendor="No Vendor Selected"
    category=""
    ops_risk=""
    biz_risk=""
    tech_risk=""
    comp_risk=""
    data_risk=""
    conc_risk=""
    final_score=""
    poc_tier=""

    if 'vendor-name' in request.GET:
        vendor = request.GET.get('vendor-name')
        category = get_col_value(vendor, 'Max Risk Service Category w/ Software LOB 1')
        ops_risk = get_col_value(vendor, 'operational risk normalized')
        biz_risk = get_col_value(vendor, 'business risk normalized')
        tech_risk = get_col_value(vendor, 'technology risk normalized')
        comp_risk = get_col_value(vendor, 'compliance risk normalized')
        data_risk = get_col_value(vendor, 'data risk normalized')
        conc_risk = get_col_value(vendor, 'Concentration Risk Normalized')
        final_score = get_col_value(vendor, 'Final Risk Score')
        poc_tier = get_col_value(vendor, 'Tier by POC')
    
    if request.method == 'POST':
        if 'vendor-name' in request.POST:
            vendor = request.POST.get('vendor-name')
            buffer = io.BytesIO()
            pdf = canvas.Canvas(buffer, pagesize=A4)
            pdf.setTitle('Vendor Report')

            width,height = A4

            heightList = [
                height * 0.05,
                height * 0.9,
                height * 0.05
            ]

            mainTable = Table([
                [getHeader(width,heightList[0])],
                [getPreBody(width,heightList[1],vendor)],
                [getFooter(width,heightList[2])]
            ], 
            colWidths=width,
            rowHeights=heightList
            )

            mainTable.setStyle([
                # ('GRID', (0, 0), (-1, -1), 1, 'red'),
                ('LEFTPADDING', (0, 0), (-1, -1), 0),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 0)
            ])

            mainTable.wrapOn(pdf, 0, 0)
            mainTable.drawOn(pdf, 0, 0)

            pdf.showPage()

            pdf.save()
            buffer.seek(0)
            return FileResponse(buffer, as_attachment=True, filename='vendor_report.pdf')

    try:
        if math.isnan(category):
            category="No Category Found"
    except:
        pass

    content = {
        "vendorname": vendor,
        "category": category,
        "risk_scores": {
            "Operational Risk": ops_risk,
            "Business Risk": biz_risk,
            "Technology Risk":tech_risk,
            "Compliance Risk":comp_risk,
            "Data Risk":data_risk,
            "Concentration Risk":conc_risk,
            "Final Risk Score": final_score,
            "Tier By POC":poc_tier
        },
        'sv':'active'
    }

    return render(request, 'capone_app/vendor_report.html',content)

def new_vendor(request):

    service_category_list = list(service_category_df['Service Category w/ Software LOB 1'])

    if request.method == 'POST':
        print(request.POST)
        if 'vendorid' in request.POST and 'category' in request.POST:
            vendorid = request.POST.get('vendorid')
            category = request.POST.get('category')
            if vendorid and category:
                return HttpResponseRedirect(reverse('capone_app:new_vendor_categorized',args=[vendorid,category]))

    content = {
        'nv':'active',
        'service_category_list':service_category_list,
    }

    return render(request, 'capone_app/new_vendor.html', content)

def new_vendor_categorized(request, vendorid, category):

    concentration_risk = float(service_category_df[service_category_df['Service Category w/ Software LOB 1']==category]['Concentration Risk Normalized'])

    viola='none'
    downloaded='none'
    questions_list = False
    response1='none'
    response2='none'
    response3='none'
    response4='none'
    response5='none'
    response6='none'
    response7='none'
    response8='none'
    response9='none'
    response10='none'
    response11='none'
    response12='none'
    response13='none'
    response14='none'
    resvar='none'

    print(request.GET)
    questions_list = [
        {
            'question':'What is the impact to Capital One if the data or information stored by the third party and/or its material subcontractor(s) is corrupted, destroyed or otherwise made unavailable?',
            'options':['There will be a significant impact to Capital One processes; the third party may or may not have the sole copy of the data.', 'There will be a moderate impact to Capital One processes; the third party has the sole copy of the data.','There will be a moderate impact to Capital One processes; the third party does not have the sole copy of the data.','There will be no impact to Capital One processes; the third party does not (1) Store the data or (2) Have the sole copy of the data.'],
            'scores':[1,0.6,0.2,0],
            'weight':{
                'operational':5,
                'data':5
            },
            'type':'Single Choice',
            'risk_areas':{
                'operational':[0,1,2,3],
                'data':[0,1,2,3]
            },
            'data_point':'Tiering Q1',
            'response_foreign_key':{
                'operational':0,
                'data':0
            }
        },
        {
            'question':'Requested RTO',
            'options':['1 Hour - 24 Hours','2 Days - 3 Days','4 Days - 14 Days','15 Days - 30 Days','Greater than 30 Days','No Recovery Required'],
            'scores':[1,0.8,0.6,0.4,0,0],
            'weight':{
                'operational':5
            },
            'type':'Single Choice',
            'risk_areas':{
                'operational':[0,1,2,3,4,5]
            },
            'data_point':'Business Continuity',
            'response_foreign_key':{
                'operational':1
            }
        },
        {
            'question':'Which of the following best describes the replaceability of the third party?',
            'options':['Extreme - The third party is extremely difficult to replace.', 'High - The third party is difficult to replace, but there are alternatives in the market.','Medium - The third party is replaceable with a moderate effort on the part of Capital One but there are alternatives in the market.','Low - The third party is easily and quickly replaceable or Capital One will not need to replace the third party.'],
            'scores':[1,0.6,0.4,0],
            'weight':{
                'operational':3
            },
            'type':'Single Choice',
            'risk_areas':{
                'operational':[0,1,2,3]
            },
            'data_point':'Tiering Q7',
            'response_foreign_key':{
                'operational':2
            }
        },
        {
            'question':'Will any aspect of the product(s) or service(s) being provided to Capital One by the third party be provided from a country that is not the same as that of the LOB receiving services?',
            'options':['Yes - Product(s) or service(s) are provided from a country that is not the same as that of the LOB receiving  services or are provided from the Philippines or India','No - Product(s) or service(s) are not being provided from a country that is not the same as that of the LOB receiving services or not being provided from the Philippines or India'],
            'scores':[1,0],
            'weight':{
                'operational':3,
                'compliance':2
            },
            'type':'Single Choice',
            'risk_areas':{
                'operational':[0,1],
                'compliance':[0,1]
            },
            'data_point':'Tiering Q10',
            'response_foreign_key':{
                'operational':3,
                'compliance':0
            }
        },
        {
            'question':'Which of the following describes the third party\'s contact with existing or prospective Capital One customers (includes Consumer and Commercial customers)?',
            'options':['Extreme - The third party has direct, two-way unscripted, real-time contact with customers related to collections and/or recoveries activities','High - The third party has direct, scripted, real-time contact with customers','Medium - The third party has indirect or one-way scripted contact with customers','None/Low - The third party does not have direct contact with customers'],
            'scores':[1,0.7142857143,0.4285714286,0],
            'weight':{
                'operational':3,
                'compliance':5,
                'business':3
            },
            'type':'Single Choice',
            'risk_areas':{
                'operational':[0,1,2,3],
                'compliance':[0,1,2,3],
                'business':[0,1,2,3]
            },
            'data_point':'Tiering Q12',
            'response_foreign_key':{
                'operational':4,
                'compliance':1,
                'business':0
            }
        },
        {
            'question':'Does the third party meet one or more of the criteria below? [Select YES if Any]\n - Have external connectivity to Capital One systems including connectivity for remote support (systems include Capital One\'s internal network and any processing or data storage system)\n - Provide customized software or code (i.e. services involve customized software or code at the request of Capital One) including externally facing websites and/or modification of open source code\n - Provide software, an application (a web, mobile, internet or other application), or hardware that is externally hosted at a third party or installed externally or on the cloud',
            'options':['Yes - One or more of the statements apply','No - None of the statements apply'],
            'scores':[1,0],
            'weight':{
                'technology':5
            },
            'type':'Single Choice',
            'risk_areas':{
                'technology':[0,1]
            },
            'data_point':'Tiering Q9',
            'response_foreign_key':{
                'technology':0
            }
        },
        {
            'question':'Does the third party use material subcontractors (fourth parties) based on the criteria below?\n\nAnswer "yes" if ANY of these statements are applicable.\nAnswer "no" if NONE of these statements are applicable.\n\n-Has the ability to connect into the Capital One network and/or access the Capital One environment in any capacity (e.g. servers, databases)\n\n-Has the ability to access (includes hosts or shares), process or store Capital One data that is classified as confidential/proprietary or confidential (refer to the Information Handling Procedure 2701.2.001 for complete definitions of classifications). Includes data stored internally (i.e. within the Capital One environment) or externally (i.e. within the third or fourth party\'s environment).\n\n-Could disrupt a Capital One mission critical process/function\n\n-Has the ability to place Capital One at risk from a legal or regulatory impact, which includes (but not limited to):\no   Is a part of the regulatory reporting process\no   Could cause harm or have a negative impact on consumers, customers, or associates\no   Requires a certification or license to perform their service (appraisers, accountants, attorneys, broker dealers, engineers, investment advisors, investors, mortgage brokers)\n\nContext: Consider scenarios that would result in the breach of a rule, law, regulatory requirement, policy and/or procedure?',
            'options':['Yes - The third party uses material subcontractors','No - The third party does not use material subcontractors'],
            'scores':[1,0],
            'weight':{
                'operational':5,
                'technology':5,
                'data':5,
                'compliance':3,
                'business':5
            },
            'type':'Single Choice',
            'risk_areas':{
                'operational':[0,1],
                'technology':[0,1],
                'data':[0,1],
                'compliance':[0,1],
                'business':[0,1]
            },
            'data_point':'Tiering Q5',
            'response_foreign_key':{
                'operational':5,
                'technology':1,
                'data':1,
                'compliance':2,
                'business':1
            }
        },
        {
            'question':'What type of Capital One data does the third party access, process or store (not including on Capital One-issued laptops)? Select the highest data classification that is applicable to the third party.',
            'options':['Confidential/Proprietary information','Confidential information','Company information','Public information','None'],
            'scores':[1,0.6153846154,0.2307692308,0,0],
            'weight':{
                'data':5,
            },
            'type':'Single Choice',
            'risk_areas':{
                'data':[0,1,2,3,4],
            },
            'data_point':'Tiering Q8',
            'response_foreign_key':{
                'data':2,
            }
        },
        {
            'question':'What is the Volume of Data Shared?',
            'options':['0','<25,000','25,001 - 100,000','100,000 - 500,000','500,001 - 1MM','1MM - 50MM','>50MM'],
            'scores':[0,0.7442,0.793,0.8312,0.933,0.9705,1],
            'weight':{
                'data':5,
            },
            'type':'Single Choice',
            'risk_areas':{
                'data':[0,1,2,3,4,5,6],
            },
            'data_point':'Data Share Tab - Data Volume',
            'response_foreign_key':{
                'data':3,
            }
        },
        {
            'question':'How many associates (third party & subcontractors) have access to Capital One data?',
            'options':['0','<10','10 - 100','>100'],
            'scores':[0,0.8848,0.9703,1],
            'weight':{
                'data':5,
            },
            'type':'Single Choice',
            'risk_areas':{
                'data':[0,1,2,3],
            },
            'data_point':'Data Share Tab - Data Access',
            'response_foreign_key':{
                'data':4,
            }
        },
        {
            'question':'ABAC Triggered (Back end data)',
            'options':['1','0'],
            'scores':[1,0],
            'weight':{
                'compliance':5,
            },
            'type':'Single Choice',
            'risk_areas':{
                'compliance':[0,1],
            },
            'data_point':'ABAC Triggered',
            'response_foreign_key':{
                'compliance':3,
            }
        },
        {
            'question':'Compliance PRG Decision',
            'options':['Pending','In scope', 'Out of scope'],
            'scores':[1,1,0],
            'weight':{
                'compliance':5,
            },
            'type':'Single Choice',
            'risk_areas':{
                'compliance':[0,1,2],
            },
            'data_point':'Compliance PRG Decision',
            'response_foreign_key':{
                'compliance':4,
            }
        },
        {
            'question':'Engagement Spend',
            'options':['0','$0 - 10,000','$10,001 - 100,000','$100,001 - 500,000','$500,001 - 1,000,000','$1,000,001 - 5,000,000','$5,000,001 - 25,000,000','$25,000,001 - 50,000,000','$50,000,001 +'],
            'scores':[0,0.4913,0.6714,0.7535,0.897,0.9791,0.9874,0.9998,1],
            'weight':{
                'business':4,
            },
            'type':'Single Choice',
            'risk_areas':{
                'business':[0,1,2,3,4,5,6,7,8],
            },
            'data_point':'Engagement Spend',
            'response_foreign_key':{
                'business':2,
            }
        },
        {
            'question':'Will the potential financial impact to Capital One reach $200 million or more if this third party failed to perform or became insolvent?',
            'options':['Yes, Financial impact to Capital One could be $200M or more','No, Financial impact to Capital One would be less than $200M.'],
            'scores':[1,0],
            'weight':{
                'business':3,
            },
            'type':'Single Choice',
            'risk_areas':{
                'business':[0,1],
            },
            'data_point':'Tier Q2',
            'response_foreign_key':{
                'business':3,
            }
        }
    ]

    if 'question1' in request.GET and 'question2' in request.GET and 'question3' in request.GET and 'question4' in request.GET and 'question5' in request.GET and 'question6' in request.GET and 'question7' in request.GET and 'question8' in request.GET and 'question9' in request.GET and 'question10' in request.GET and 'question11' in request.GET and 'question12' in request.GET and 'question13' in request.GET and 'question14' in request.GET:
        response1 = request.GET.getlist('question1')
        response2 = request.GET.getlist('question2')
        response3 = request.GET.getlist('question3')
        response4 = request.GET.getlist('question4')
        response5 = request.GET.getlist('question5')
        response6 = request.GET.getlist('question6')
        response7 = request.GET.getlist('question7')
        response8 = request.GET.getlist('question8')
        response9 = request.GET.getlist('question9')
        response10 = request.GET.getlist('question10')
        response11 = request.GET.getlist('question11')
        response12 = request.GET.getlist('question12')
        response13 = request.GET.getlist('question13')
        response14 = request.GET.getlist('question14')
        print(response1, response2, response3, response4, response5, response6, response7, response8, response9, response10, response11, response12, response13, response14)
        if response1 and response2 and response3 and response4 and response5 and response6 and response7 and response8 and response9 and response10 and response11 and response12 and response13 and response14:
            responses_list = [response1,response2,response3,response4,response5,response6,response7,response8,response9,response10,response11,response12,response13,response14]
            if 'generate' in request.GET:
                viola='inline-block'
            if 'download' in request.GET:
                downloaded='inline-block'
                buffer = io.BytesIO()
                pdf = canvas.Canvas(buffer, pagesize=A4)
                pdf.setTitle('Vendor Report')

                width,height = A4

                heightList = [
                    height * 0.05,
                    height * 0.9,
                    height * 0.05
                ]

                mainTable = Table([
                    [getHeader(width,heightList[0])],
                    [getBody(width,heightList[1],vendorid,category,questions_list,responses_list,concentration_risk)],
                    [getFooter(width,heightList[2])]
                ], 
                colWidths=width,
                rowHeights=heightList
                )

                mainTable.setStyle([
                    # ('GRID', (0, 0), (-1, -1), 1, 'red'),
                    ('LEFTPADDING', (0, 0), (-1, -1), 0),
                    ('BOTTOMPADDING', (0, 0), (-1, -1), 0)
                ])

                mainTable.wrapOn(pdf, 0, 0)
                mainTable.drawOn(pdf, 0, 0)

                pdf.showPage()

                heightList = [
                    height * 0.05,
                    height * 0.9,
                    height * 0.05
                ]

                mainTable = Table([
                    [''],
                    [getPage2Body(width,heightList[1],questions_list,responses_list)],
                    [getFooter(width,heightList[2])]
                ], 
                colWidths=width,
                rowHeights=heightList
                )

                mainTable.setStyle([
                    # ('GRID', (0, 0), (-1, -1), 1, 'red'),
                    ('LEFTPADDING', (0, 0), (-1, -1), 0),
                    ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
                    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                    ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ])

                mainTable.wrapOn(pdf, 0, 0)
                mainTable.drawOn(pdf, 0, 0)

                pdf.showPage()

                heightList = [
                    height * 0.05,
                    height * 0.9,
                    height * 0.05
                ]

                mainTable = Table([
                    [''],
                    [getPage3Body(width,heightList[1],questions_list,responses_list)],
                    [getFooter(width,heightList[2])]
                ], 
                colWidths=width,
                rowHeights=heightList
                )

                mainTable.setStyle([
                    # ('GRID', (0, 0), (-1, -1), 1, 'red'),
                    ('LEFTPADDING', (0, 0), (-1, -1), 0),
                    ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
                    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                    ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ])

                mainTable.wrapOn(pdf, 0, 0)
                mainTable.drawOn(pdf, 0, 0)

                pdf.showPage()

                pdf.save()
                buffer.seek(0)
                return FileResponse(buffer, as_attachment=True, filename='vendor_report.pdf')

    content = {
        'nv':'active',
        'viola':viola,
        'downloaded':downloaded,
        'vendorid':vendorid,
        'category':category,
        'questions_list':questions_list,
        'response1':response1,
        'response2':response2,
        'response3':response3,
        'response4':response4,
        'resvar':resvar
    }

    return render(request, 'capone_app/new_vendor_categorized.html', content)

def prioritized_vendor_list(request, vendor_count=100):

    vendors_list = risk_df[risk_df['Final Risk Score'].notna()].sort_values('Final Risk Score', ascending=False).head(100).to_dict('records')
    paginator = Paginator(vendors_list, vendor_count)
    print(paginator.page(1).object_list)
    page = request.GET.get('page',1)
    try:
        vendors = paginator.page(page)
    except PageNotAnInteger:
        vendors = paginator.page(1)
    except EmptyPage:
        vendors = paginator.page(paginator.num_pages)
    
    content = {
        "vendors": vendors,
        'pvl':'active'
    }

    return render(request, 'capone_app/prioritized_vendor_list.html', content)

def modeling_description(request):
    content = {'md':'active'}
    return render(request, 'capone_app/modeling_description.html', content)
