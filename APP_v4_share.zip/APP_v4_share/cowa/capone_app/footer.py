from reportlab.platypus import Table, Image, Paragraph
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle

def getFooter(width, height):

    widthList = [
        width * 0.05,
        width * 0.9,
        width * 0.05
    ]

    res = Table([
            ['','',''],
        ],
        widthList,
        height,
    )

    res.setStyle([
        #('GRID', (0,0), (-1,-1), 1, 'red'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ])

    return res