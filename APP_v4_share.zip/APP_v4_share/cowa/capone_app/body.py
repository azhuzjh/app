from reportlab.platypus import Table, Image, Paragraph
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
import os

import plotly.graph_objects as go
from plotly.subplots import make_subplots

import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from statistics import mean
import math

ops_risk_overflow_flag = False
tech_risk_overflow_flag = False
comp_risk_overflow_flag = False
biz_risk_overflow_flag = False
data_risk_overflow_flag = False

concentration_risk_weight_ops = 3
concentration_risk_weight_tech = 3
concentration_risk_weight_comp = 2
concentration_risk_weight_biz = 3
concentration_risk_weight_data = 3

tier_level = 0
recommended_riq_questions = []

base_path = str(os.path.abspath(os.path.dirname(__name__))) + "/capone_app/"
risk_df = pd.read_csv(str(os.path.abspath(os.path.dirname(__name__))) + "/capone_app/Final Risk Table 2.0.csv")
risk_df_riq = pd.read_csv(str(os.path.abspath(os.path.dirname(__name__))) + "/capone_app/Final Risk Table 3.0.csv")

#Helper Functions

def get_col_value(vendor, col_name):
    """Helper function to get column value of a vendor or asset based on column name"""
    col_value = ""
    
    vendor_row = risk_df.loc[risk_df["18 Digit ID"] == vendor]
    
    if len(vendor_row.index)!=0:
        col_value = vendor_row[col_name].iloc[0]
    
    return col_value

def pre_draw_risk_areas_png(vendorid):
    
    global tier_level

    print(vendorid)

    category = get_col_value(vendorid, 'Max Risk Service Category w/ Software LOB 1')
    ops_risk = get_col_value(vendorid, 'operational risk normalized')
    biz_risk = get_col_value(vendorid, 'business risk normalized')
    tech_risk = get_col_value(vendorid, 'technology risk normalized')
    comp_risk = get_col_value(vendorid, 'compliance risk normalized')
    data_risk = get_col_value(vendorid, 'data risk normalized')
    conc_risk = get_col_value(vendorid, 'Concentration Risk Normalized')
    final_risk = get_col_value(vendorid, 'Final Risk Score')
    tier_level = get_col_value(vendorid, 'Tier by POC')

    print("ops_risk: ",ops_risk)
    print("tech_risk: ",tech_risk)
    print("comp_risk: ",comp_risk)
    print("biz_risk: ",biz_risk)
    print("data_risk: ",data_risk)

    fig = go.Figure(go.Indicator(
    domain = {'x': [0, 1], 'y': [0, 1]},
    value = final_risk,
    mode = "gauge+number+delta",
    title = {'text': "Inherent Risk Score"},
    delta = {'reference': 0.34219566027827536},
    gauge = {'axis': {'range': [None, 1]},
             'steps' : [
                 {'range': [0, 0.268], 'color': "lightgray"},
                 {'range': [0.268, 0.616], 'color': "gray"},
                 {'range': [0.616, 0.8], 'color': "orange"},
                 {'range': [0.8, 1], 'color': "red"}],
             'threshold' : {'line': {'color': "red", 'width': 1}, 'thickness': 0.75, 'value': 1}})).add_annotation(dict(text='Deviation from population average of inherent risk score',y=0.03,showarrow=False))
    fig.write_image(base_path+'resources/inherent_risk_gauge.png')

    ops_risk = round(ops_risk,2)
    tech_risk = round(tech_risk,2)
    comp_risk = round(comp_risk,2)
    biz_risk = round(biz_risk,2)
    data_risk = round(data_risk,2)
    final_risk = round(final_risk,2)
    concentration_risk = round(conc_risk,2)

    print("ops_risk: ",ops_risk)
    print("tech_risk: ",tech_risk)
    print("comp_risk: ",comp_risk)
    print("biz_risk: ",biz_risk)
    print("data_risk: ",data_risk)

    risk_list = [concentration_risk, ops_risk, biz_risk, tech_risk, data_risk, comp_risk]

    df = pd.read_csv(base_path + "Final Risk Table 2.0.csv")
    try:
        if math.isnan(category):
            sub = df[df["Max Risk Service Category w/ Software LOB 1"].isnull()]
        else:
            sub = df[df["Max Risk Service Category w/ Software LOB 1"] == category]
    except:
        sub = df[df["Max Risk Service Category w/ Software LOB 1"] == category]

    risk_list_avg = [round(mean(df["Concentration Risk Normalized"]),2),
    round(mean(df["operational risk normalized"]),2),
    round(mean(df["business risk normalized"]),2),
    round(mean(df["technology risk normalized"]),2),
    round(mean(df["data risk normalized"]),2),
    round(mean(df["compliance risk normalized"]),2)]
    risk_list_avg_cat = [round(mean(sub["Concentration Risk Normalized"]),2),
    round(mean(sub["operational risk normalized"]),2),
    round(mean(sub["business risk normalized"]),2),
    round(mean(sub["technology risk normalized"]),2),
    round(mean(sub["data risk normalized"]),2),
    round(mean(sub["compliance risk normalized"]),2)]
    font_color = '#525252'
    csfont = {'fontname':'Georgia'} # title font
    hfont = {'fontname':'Calibri'} # main font
    plotdata = pd.DataFrame({
        "New Vendor":risk_list,
        "Averge of Same Category":risk_list_avg_cat,
        "Averge of Full Population":risk_list_avg},
        index=["Concentration", "Operatinal", "Business", "Tech", "Data", "Compliance"]
    )
    colors = ['#650021', '#008000', '#00008B']
    ax = plotdata.plot(kind="barh", stacked=False, figsize=(10, 6), color=colors)
    for container in ax.containers:
        ax.bar_label(container)
    for label in (ax.get_xticklabels() + ax.get_yticklabels()):
        label.set_fontsize(15)

    title = plt.title('Risk Component Scores', pad=20, fontsize=28, color=font_color, **csfont)
    title.set_position([.5, 1.02])
    plt.xlabel("Risk Score", fontsize=20)
    plt.ylabel("Risk Component", fontsize=20)
    plt.xticks(color=font_color, **hfont)
    plt.yticks(color=font_color, **hfont)
    plt.xlim(0, 1)

    plt.savefig(base_path+'resources/risk_areas.png', bbox_inches='tight')
    plt.clf()
    plt.cla()
    plt.close()

    full_data = pd.read_csv(base_path+"Final Risk Table 2.0.csv")
    try:
        if math.isnan(category):
            sub_data = full_data[full_data["Max Risk Service Category w/ Software LOB 1"].isnull()]
        else:
            sub_data = full_data[full_data["Max Risk Service Category w/ Software LOB 1"] == category] # add same service category dots
    except:
        sub_data = full_data[full_data["Max Risk Service Category w/ Software LOB 1"] == category] # add same service category dots
        
    roc_t = 0.5
    roc_v = 0.5
    font_color = '#525252'
    csfont = {'fontname':'Georgia'} # title font
    hfont = {'fontname':'Calibri'} # main font
    colors = ['#650021', '#C0C0C0']
    T_Cutoff = roc_t
    V_Cutoff = roc_v
    fig,ax = plt.subplots(figsize=(15,12))
    ax.set_xlim(-0,1)
    ax.set_ylim(-0,1)
    for label in (ax.get_xticklabels() + ax.get_yticklabels()):
        label.set_fontsize(15)
    plt.plot(full_data['Final Risk Score'],full_data['Concentration Risk Normalized'],"o", color='#929591')
    ax.axvline(T_Cutoff,color = 'black',linestyle='dashed',lw=2)
    ax.axhline(V_Cutoff,color = 'black',linestyle='dashed',lw=2)
    plt.plot(sub_data['Final Risk Score'],sub_data['Concentration Risk Normalized'],"o", markersize = 10, color='#008000', alpha=0.8) ## sub plot by service category
    ax.axvline(T_Cutoff,color = 'black',linestyle='dashed',lw=2)
    plt.scatter([concentration_risk], [final_risk], color = 'red', marker='X', s=500)
    plt.text(concentration_risk, final_risk, '  ({}, {})'.format(concentration_risk,final_risk),fontsize='xx-large',fontweight='heavy',va="bottom")
    plt.xlabel("Concentration Risk Score", fontsize=20)
    plt.ylabel("Risk Score", fontsize=20)
    plt.title("Risk Position in Entire Population",pad=30, fontsize=28, color=font_color, **csfont)
    ax.fill_between([-0.5, roc_t],-0.5,roc_v,alpha=0.3, color='#1F98D0')  # blue
    ax.fill_between([roc_t, 1.4], -0.5, roc_v, alpha=0.3, color='#F9D307')  # yellow
    ax.fill_between([-0.5, roc_t], roc_v, 1.4, alpha=0.3, color='#F38D25')  # orange
    ax.fill_between([roc_t, 1.4], roc_v, 1.4, alpha=0.3, color='#E50000')  # red

    custom = [Line2D([], [], marker='.', markersize=20, color='#929591', linestyle='None'),
    Line2D([], [], marker='.', markersize=20, color='#008000', linestyle='None')]
    plt.legend(custom, ['Full Population', 'Population in same service category'], loc='upper right', fontsize=15)

    plt.savefig(base_path+'resources/risk_position.png')
    plt.clf()
    plt.cla()
    plt.close()

def draw_risk_areas_png(category, questions_list,responses_list,concentration_risk):

    global tier_level
    global recommended_riq_questions

    ops_risk = calc_ops_risk(questions_list,responses_list,concentration_risk)
    tech_risk = calc_tech_risk(questions_list,responses_list,concentration_risk)
    comp_risk = calc_comp_risk(questions_list,responses_list,concentration_risk)
    biz_risk = calc_biz_risk(questions_list,responses_list,concentration_risk)
    data_risk = calc_data_risk(questions_list,responses_list,concentration_risk)

    final_risk = (ops_risk * 0.25) + (tech_risk * 0.2) + (comp_risk * 0.2) + (biz_risk * 0.15) + (data_risk * 0.2)

    if final_risk<=0.268:
        tier_level = 4
    elif final_risk>0.268 and final_risk<=0.616:
        tier_level = 3
    elif final_risk>0.616 and final_risk<=0.8:
        tier_level = 2
    elif final_risk>0.8 and final_risk<=1:
        tier_level = 1

    fig = go.Figure(go.Indicator(
    domain = {'x': [0, 1], 'y': [0, 1]},
    value = final_risk,
    mode = "gauge+number+delta",
    title = {'text': "Inherent Risk Score"},
    delta = {'reference': 0.34219566027827536},
    gauge = {'axis': {'range': [None, 1]},
             'steps' : [
                 {'range': [0, 0.268], 'color': "lightgray"},
                 {'range': [0.268, 0.616], 'color': "gray"},
                 {'range': [0.616, 0.8], 'color': "orange"},
                 {'range': [0.8, 1], 'color': "red"}],
             'threshold' : {'line': {'color': "red", 'width': 1}, 'thickness': 0.75, 'value': 1}})).add_annotation(dict(text='Deviation from population average of inherent risk score',y=0.03,showarrow=False))
    fig.write_image(base_path+'resources/inherent_risk_gauge.png')

    riq_rec_quest = pd.read_csv(base_path+"Recommended RIQ Questions by Service Category.csv")
    riq_parent_taxonomy_questions = pd.read_csv(base_path+"Recommended RIQ Parent Questions by L1 Risk Category.csv")

    risk_area_cutoffs = {"Business" : 0.5, 
                        "Compliance" : 0.6, 
                        "Data" : 0.3, 
                        "Operational" : 0.5, 
                        "Technology" : 0.6}

    example_third_party = {"Service Category": category,
                        "operational risk normalized": ops_risk,
                        "business risk normalized" : biz_risk,
                        "technology risk normalized": tech_risk,
                        "compliance risk normalized": comp_risk,
                        "data risk normalized" : data_risk}

    print(recommended_riq_questions,type(recommended_riq_questions))
    recommended_riq_questions.extend(riq_rec_quest.loc[riq_rec_quest["Service Category"] == example_third_party["Service Category"], "Recommended RIQ Questions"].iloc[0][1:-1].split(", "))

    for area in risk_area_cutoffs:
        area_lower = area.lower()
        if example_third_party[area_lower + " risk normalized"] > risk_area_cutoffs[area]:
            recommended_riq_questions.extend(riq_parent_taxonomy_questions.loc[riq_parent_taxonomy_questions["Model Risk Area"] == area, "RIQ Questions"].iloc[0][2:-2].split("', '"))

    recommended_riq_questions = sorted(list(set([float(quest) for quest in recommended_riq_questions])))

    ops_risk = round(ops_risk,2)
    tech_risk = round(tech_risk,2)
    comp_risk = round(comp_risk,2)
    biz_risk = round(biz_risk,2)
    data_risk = round(data_risk,2)
    final_risk = round(final_risk,2)
    concentration_risk = round(concentration_risk,2)


    print("ops_risk: ",ops_risk)
    print("tech_risk: ",tech_risk)
    print("comp_risk: ",comp_risk)
    print("biz_risk: ",biz_risk)
    print("data_risk: ",data_risk)

    # specs = [[{'type':'domain'},{'type':'domain'},{'type':'domain'}],[{'type':'domain'},{'type':'domain'},{'type':'domain'}]]
    # fig = make_subplots(rows=2,cols=3,specs=specs)

    # ops_labels = ['Operational Risk',' ']
    # ops_values =  [ops_risk, 1 - ops_risk]
    # ops_name="Operational Risk"

    # tech_labels = ['Technology Risk',' ']
    # tech_values =  [tech_risk, 1 - tech_risk]
    # tech_name="Technology Risk"

    # comp_labels = ['Compliance Risk',' ']
    # comp_values =  [comp_risk, 1 - comp_risk]
    # comp_name="Compliance Risk"

    # biz_labels = ['Business Risk',' ']
    # biz_values =  [biz_risk, 1 - biz_risk]
    # biz_name="Business Risk"

    # data_labels = ['Data Risk',' ']
    # data_values =  [data_risk, 1 - data_risk]
    # data_name="Data Risk"

    # fig.add_trace(go.Pie(labels=ops_labels,values=ops_values,name=ops_name,marker_colors=['red','whitesmoke']),1,1)
    # fig.add_trace(go.Pie(labels=tech_labels,values=tech_values,name=tech_name,marker_colors=['blue','whitesmoke']),1,2)
    # fig.add_trace(go.Pie(labels=comp_labels,values=comp_values,name=comp_name,marker_colors=['green','whitesmoke']),1,3)
    # fig.add_trace(go.Pie(labels=biz_labels,values=biz_values,name=biz_name,marker_colors=['yellow','whitesmoke']),2,1)
    # fig.add_trace(go.Pie(labels=data_labels,values=data_values,name=data_name,marker_colors=['orange','whitesmoke']),2,2)

    # fig.update_traces(textinfo='value',hole=0.5) ## add this line to dislay value rather than percentage

    # fig=go.Figure(fig)
    # fig.write_image(base_path+'resources/risk_areas.png')

    risk_list = [concentration_risk, ops_risk, biz_risk, tech_risk, data_risk, comp_risk]

    df = pd.read_csv(base_path + "Final Risk Table 2.0.csv")
    try:
        if math.isnan(category):
            sub = df[df["Max Risk Service Category w/ Software LOB 1"].isnull()]
        else:
            sub = df[df["Max Risk Service Category w/ Software LOB 1"] == category]
    except:
        sub = df[df["Max Risk Service Category w/ Software LOB 1"] == category]
    risk_list_avg = [round(mean(df["Concentration Risk Normalized"]),2),
    round(mean(df["operational risk normalized"]),2),
    round(mean(df["business risk normalized"]),2),
    round(mean(df["technology risk normalized"]),2),
    round(mean(df["data risk normalized"]),2),
    round(mean(df["compliance risk normalized"]),2)]
    risk_list_avg_cat = [round(mean(sub["Concentration Risk Normalized"]),2),
    round(mean(sub["operational risk normalized"]),2),
    round(mean(sub["business risk normalized"]),2),
    round(mean(sub["technology risk normalized"]),2),
    round(mean(sub["data risk normalized"]),2),
    round(mean(sub["compliance risk normalized"]),2)]
    font_color = '#525252'
    csfont = {'fontname':'Georgia'} # title font
    hfont = {'fontname':'Calibri'} # main font
    plotdata = pd.DataFrame({
        "New Vendor":risk_list,
        "Averge of Same Category":risk_list_avg_cat,
        "Averge of Full Population":risk_list_avg},
        index=["Concentration", "Operational", "Business", "Tech", "Data", "Compliance"]
    )
    colors = ['#650021', '#008000', '#00008B']
    ax = plotdata.plot(kind="barh", stacked=False, figsize=(10, 6), color=colors)
    for container in ax.containers:
        ax.bar_label(container)
    for label in (ax.get_xticklabels() + ax.get_yticklabels()):
        label.set_fontsize(15)

    title = plt.title('Risk Component Scores', pad=20, fontsize=28, color=font_color, **csfont)
    title.set_position([.5, 1.02])
    plt.xlabel("Risk Score", fontsize=20)
    plt.ylabel("Risk Component", fontsize=20)
    plt.xticks(color=font_color, **hfont)
    plt.yticks(color=font_color, **hfont)
    plt.xlim(0, 1)

    plt.savefig(base_path+'resources/risk_areas.png', bbox_inches='tight')
    plt.clf()
    plt.cla()
    plt.close()

    full_data = pd.read_csv(base_path+"Final Risk Table 2.0.csv")
    try:
        if math.isnan(category):
            sub_data = full_data[full_data["Max Risk Service Category w/ Software LOB 1"].isnull()]
        else:
            sub_data = full_data[full_data["Max Risk Service Category w/ Software LOB 1"] == category] # add same service category dots
    except:
        sub_data = full_data[full_data["Max Risk Service Category w/ Software LOB 1"] == category] # add same service category dots
    roc_t = 0.5
    roc_v = 0.5
    font_color = '#525252'
    csfont = {'fontname':'Georgia'} # title font
    hfont = {'fontname':'Calibri'} # main font
    colors = ['#650021', '#C0C0C0']
    T_Cutoff = roc_t
    V_Cutoff = roc_v
    fig,ax = plt.subplots(figsize=(15,12))
    ax.set_xlim(-0,1)
    ax.set_ylim(-0,1)
    for label in (ax.get_xticklabels() + ax.get_yticklabels()):
        label.set_fontsize(15)
    plt.plot(full_data['Final Risk Score'],full_data['Concentration Risk Normalized'],"o", color='#929591')
    ax.axvline(T_Cutoff,color = 'black',linestyle='dashed',lw=2)
    ax.axhline(V_Cutoff,color = 'black',linestyle='dashed',lw=2)
    plt.plot(sub_data['Final Risk Score'],sub_data['Concentration Risk Normalized'],"o", markersize = 10, color='#008000', alpha=0.8) ## sub plot by service category
    ax.axvline(T_Cutoff,color = 'black',linestyle='dashed',lw=2)
    plt.scatter([concentration_risk], [final_risk], color = 'red', marker='X', s=500)
    plt.text(concentration_risk, final_risk, '  ({}, {})'.format(concentration_risk,final_risk),fontsize='xx-large',fontweight='heavy',va="bottom")
    plt.xlabel("Concentration Risk Score", fontsize=20)
    plt.ylabel("Risk Score", fontsize=20)
    plt.title("Risk Position in Entire Population",pad=30, fontsize=28, color=font_color, **csfont)
    ax.fill_between([-0.5, roc_t],-0.5,roc_v,alpha=0.3, color='#1F98D0')  # blue
    ax.fill_between([roc_t, 1.4], -0.5, roc_v, alpha=0.3, color='#F9D307')  # yellow
    ax.fill_between([-0.5, roc_t], roc_v, 1.4, alpha=0.3, color='#F38D25')  # orange
    ax.fill_between([roc_t, 1.4], roc_v, 1.4, alpha=0.3, color='#E50000')  # red

    custom = [Line2D([], [], marker='.', markersize=20, color='#929591', linestyle='None'),
    Line2D([], [], marker='.', markersize=20, color='#008000', linestyle='None')]
    plt.legend(custom, ['Full Population', 'Population in same service category'], loc='upper right', fontsize=15)

    plt.savefig(base_path+'resources/risk_position.png')
    plt.clf()
    plt.cla()
    plt.close()

def calc_ops_risk(questions_list, responses_list, concentration_risk):
    
    current_questions_list, current_responses_list = current_questions_responses_list(questions_list,responses_list,'operational')

    print("ops cql: ",current_questions_list)
    print("\nops crl: ",current_responses_list)

    max_ops_risk = 24.98062795265594

    t1_weight = 0
    rto_weight = 0
    t7_weight = 0
    t10_weight = 0
    t12_weight = 0
    t5_weight = 0
    
    t1_score = 0
    rto_score = 0
    t7_score = 0
    t10_score = 0
    t12_score = 0
    t5_score = 0

    for question in current_questions_list:
        if question['data_point'] == 'Tiering Q1':
            t1_weight = question['weight']['operational']
            i=0
            for option in question['options']:
                for response_option in current_responses_list[question['response_foreign_key']['operational']]:
                    if option == response_option:
                        t1_score += question['scores'][i]
                i+=1

        elif question['data_point'] == 'Business Continuity':
            rto_weight = question['weight']['operational']
            i=0
            for option in question['options']:
                for response_option in current_responses_list[question['response_foreign_key']['operational']]:
                    if option == response_option:
                        rto_score += question['scores'][i]
                i+=1

        elif question['data_point'] == 'Tiering Q7':
            t7_weight = question['weight']['operational']
            i=0
            for option in question['options']:
                for response_option in current_responses_list[question['response_foreign_key']['operational']]:
                    if option == response_option:
                        t7_score += question['scores'][i]
                i+=1

        elif question['data_point'] == 'Tiering Q10':
            t10_weight = question['weight']['operational']
            i=0
            for option in question['options']:
                for response_option in current_responses_list[question['response_foreign_key']['operational']]:
                    if option == response_option:
                        t10_score += question['scores'][i]
                i+=1

        elif question['data_point'] == 'Tiering Q12':
            t12_weight = question['weight']['operational']
            i=0
            for option in question['options']:
                for response_option in current_responses_list[question['response_foreign_key']['operational']]:
                    if option == response_option:
                        t12_score += question['scores'][i]
                i+=1

        elif question['data_point'] == 'Tiering Q5':
            t5_weight = question['weight']['operational']
            i=0
            for option in question['options']:
                for response_option in current_responses_list[question['response_foreign_key']['operational']]:
                    if option == response_option:
                        t5_score += question['scores'][i]
                i+=1
        

    print('t1_weight: ',t1_weight,'t1_score: ',t1_score)
    print('rto_weight: ',rto_weight,'rto_score: ',rto_score)
    print('t7_weight: ',t7_weight,'t7_score: ',t7_score)
    print('t10_weight: ',t10_weight,'t10_score: ',t10_score)
    print('t12_weight: ',t12_weight,'t12_score: ',t12_score)
    print('t5_weight: ',t5_weight,'t5_score: ',t5_score)

    ops_risk = t1_weight * t1_score + t7_weight * t7_score + t10_weight * t10_score + t12_weight * t12_score + t5_weight * t5_score + rto_weight * rto_score + concentration_risk_weight_ops * concentration_risk

    print("Calc ops_risk:",ops_risk)

    if ops_risk>max_ops_risk:
        ops_risk_overflow_flag = ops_risk
        ops_risk = max_ops_risk

    ops_risk /= max_ops_risk
    print("Norm ops_risk:",ops_risk)

    return ops_risk

def calc_tech_risk(questions_list, responses_list, concentration_risk):
    
    current_questions_list, current_responses_list = current_questions_responses_list(questions_list,responses_list,'technology')

    print("tech cql: ",current_questions_list)
    print("\ntech crl: ",current_responses_list)

    max_tech_risk = 13.000000

    t9_weight=0
    t5_weight=0

    t9_score=0
    t5_score=0

    for question in current_questions_list:
        if question['data_point'] == 'Tiering Q9':
            t9_weight = question['weight']['technology']
            i=0
            for option in question['options']:
                for response_option in current_responses_list[question['response_foreign_key']['technology']]:
                    if option == response_option:
                        t9_score += question['scores'][i]
                i+=1

        elif question['data_point'] == 'Tiering Q5':
            t5_weight = question['weight']['technology']
            i=0
            for option in question['options']:
                for response_option in current_responses_list[question['response_foreign_key']['technology']]:
                    if option == response_option:
                        t5_score += question['scores'][i]
                i+=1

    print('t9_weight: ',t9_weight,'t9_score: ',t9_score)
    print('t5_weight: ',t5_weight,'t5_score: ',t5_score)

    tech_risk = t9_score * (t9_weight + (t5_score * t5_weight) + (concentration_risk * concentration_risk_weight_tech))

    print("Calc tech_risk:",tech_risk)

    if tech_risk>max_tech_risk:
        tech_risk_overflow_flag = tech_risk
        tech_risk = max_tech_risk

    tech_risk /= max_tech_risk
    print("Norm tech_risk:",tech_risk)

    return tech_risk

def calc_biz_risk(questions_list, responses_list, concentration_risk):
    
    current_questions_list, current_responses_list = current_questions_responses_list(questions_list,responses_list,'business')

    print("biz cql: ",current_questions_list)
    print("\nbiz crl: ",current_responses_list)

    max_biz_risk = 15.598880

    spend_weight=0
    t2_weight=0
    t12_weight=0
    t5_weight=0

    spend_score=0
    t2_score=0
    t12_score=0
    t5_score=0

    for question in current_questions_list:
        if question['data_point'] == 'Engagement Spend':
            spend_weight = question['weight']['business']
            i=0
            for option in question['options']:
                for response_option in current_responses_list[question['response_foreign_key']['business']]:
                    if option == response_option:
                        spend_score += question['scores'][i]
                i+=1

        elif question['data_point'] == 'Tier Q2':
            t2_weight = question['weight']['business']
            i=0
            for option in question['options']:
                for response_option in current_responses_list[question['response_foreign_key']['business']]:
                    if option == response_option:
                        t2_score += question['scores'][i]
                i+=1

        elif question['data_point'] == 'Tiering Q12':
            t12_weight = question['weight']['business']
            i=0
            for option in question['options']:
                for response_option in current_responses_list[question['response_foreign_key']['business']]:
                    if option == response_option:
                        t12_score += question['scores'][i]
                i+=1

        elif question['data_point'] == 'Tiering Q5':
            t5_weight = question['weight']['business']
            i=0
            for option in question['options']:
                for response_option in current_responses_list[question['response_foreign_key']['business']]:
                    if option == response_option:
                        t5_score += question['scores'][i]
                i+=1

    print('spend_weight: ',spend_weight,'spend_score: ',spend_score)
    print('t2_weight: ',t2_weight,'t2_score: ',t2_score)
    print('t12_weight: ',t12_weight,'t12_score: ',t12_score)
    print('t5_weight: ',t5_weight,'t5_score: ',t5_score)

    biz_risk = (spend_score * spend_weight) + (t2_score * t2_weight) + (t12_score * t12_weight) + (t5_score * t5_weight) + (concentration_risk * concentration_risk_weight_biz)

    print("Calc biz_risk:",biz_risk)

    if biz_risk>max_biz_risk:
        biz_risk_overflow_flag = biz_risk
        biz_risk = max_biz_risk

    biz_risk /= max_biz_risk
    print("Norm biz_risk:",biz_risk)

    return biz_risk

def calc_data_risk(questions_list, responses_list, concentration_risk):
    
    current_questions_list, current_responses_list = current_questions_responses_list(questions_list,responses_list,'data')

    print("data cql: ",current_questions_list)
    print("\ndata crl: ",current_responses_list)

    max_data_risk = 27.704

    t1_weight=0
    t8_weight=0
    t5_weight=0
    dv_weight=0 #data volume - dv
    da_weight=0 #data access - da

    t1_score=0
    t8_score=0
    t5_score=0
    dv_score=0
    da_score=0

    for question in current_questions_list:
        if question['data_point'] == 'Tiering Q1':
            t1_weight = question['weight']['data']
            i=0
            for option in question['options']:
                for response_option in current_responses_list[question['response_foreign_key']['data']]:
                    if option == response_option:
                        t1_score += question['scores'][i]
                i+=1

        elif question['data_point'] == 'Tiering Q8':
            t8_weight = question['weight']['data']
            i=0
            for option in question['options']:
                for response_option in current_responses_list[question['response_foreign_key']['data']]:
                    if option == response_option:
                        t8_score += question['scores'][i]
                i+=1

        elif question['data_point'] == 'Tiering Q5':
            t5_weight = question['weight']['data']
            i=0
            for option in question['options']:
                for response_option in current_responses_list[question['response_foreign_key']['data']]:
                    if option == response_option:
                        t5_score += question['scores'][i]
                i+=1

        elif question['data_point'] == 'Data Share Tab - Data Volume':
            dv_weight = question['weight']['data']
            i=0
            for option in question['options']:
                for response_option in current_responses_list[question['response_foreign_key']['data']]:
                    if option == response_option:
                        dv_score += question['scores'][i]
                i+=1

        elif question['data_point'] == 'Data Share Tab - Data Access':
            da_weight = question['weight']['data']
            i=0
            for option in question['options']:
                for response_option in current_responses_list[question['response_foreign_key']['data']]:
                    if option == response_option:
                        da_score += question['scores'][i]
                i+=1

    print('t1_weight: ',t1_weight,'t1_score: ',t1_score)
    print('t8_weight: ',t8_weight,'t8_score: ',t8_score)
    print('t5_weight: ',t5_weight,'t5_score: ',t5_score)
    print('dv_weight: ',dv_weight,'dv_score: ',dv_score)    
    print('da_weight: ',da_weight,'da_score: ',da_score)

    data_risk = t1_weight * t1_score + t8_weight * t8_score + dv_weight * dv_score + da_weight * da_score + t5_weight * t5_score + concentration_risk_weight_data * concentration_risk
    print("Calc data_risk:",data_risk)

    if data_risk>max_data_risk:
        data_risk_overflow_flag = data_risk
        data_risk = max_data_risk

    data_risk /= max_data_risk
    print("Norm data_risk:",data_risk)

    return data_risk

def calc_comp_risk(questions_list, responses_list, concentration_risk):
    
    current_questions_list, current_responses_list = current_questions_responses_list(questions_list,responses_list,'compliance')

    print("comp cql: ",current_questions_list)
    print("\ncomp crl: ",current_responses_list)

    max_comp_risk = 20.828944

    trigger = 1

    abac_weight=0
    prg_weight=0
    t10_weight=0
    t12_weight=0
    t5_weight=0

    abac_score=0
    prg_score=0
    t10_score=0
    t12_score=0
    t5_score=0

    for question in current_questions_list:
        if question['data_point'] == 'ABAC Triggered':
            abac_weight = question['weight']['compliance']
            i=0
            for option in question['options']:
                for response_option in current_responses_list[question['response_foreign_key']['compliance']]:
                    if option == response_option:
                        abac_score += question['scores'][i]
                i+=1

        elif question['data_point'] == 'Compliance PRG Decision':
            prg_weight = question['weight']['compliance']
            i=0
            for option in question['options']:
                for response_option in current_responses_list[question['response_foreign_key']['compliance']]:
                    if option == response_option:
                        prg_score += question['scores'][i]
                i+=1

        elif question['data_point'] == 'Tiering Q10':
            t10_weight = question['weight']['compliance']
            i=0
            for option in question['options']:
                for response_option in current_responses_list[question['response_foreign_key']['compliance']]:
                    if option == response_option:
                        t10_score += question['scores'][i]
                i+=1

        elif question['data_point'] == 'Tiering Q12':
            t12_weight = question['weight']['compliance']
            i=0
            for option in question['options']:
                for response_option in current_responses_list[question['response_foreign_key']['compliance']]:
                    if option == response_option:
                        t12_score += question['scores'][i]
                i+=1

        elif question['data_point'] == 'Tiering Q5':
            t5_weight = question['weight']['compliance']
            i=0
            for option in question['options']:
                for response_option in current_responses_list[question['response_foreign_key']['compliance']]:
                    if option == response_option:
                        t5_score += question['scores'][i]
                i+=1

    if abac_score == 0 and prg_score == 0:
        trigger = 0

    print('trigger: ',trigger)
    print('abac_weight: ',abac_weight,'abac_score: ',abac_score)
    print('prg_weight: ',prg_weight,'prg_score: ',prg_score)
    print('t10_weight: ',t10_weight,'t10_score: ',t10_score)
    print('t12_weight: ',t12_weight,'t12_score: ',t12_score)
    print('t5_weight: ',t5_weight,'t5_score: ',t5_score)

    comp_risk = (trigger) * ((abac_score * abac_weight) + (prg_score * prg_weight) + (t10_score * t10_weight) + (t12_score * t12_weight) + (t5_score * t5_weight) + (concentration_risk * concentration_risk_weight_comp))
    
    print("Calc comp_risk:",comp_risk)

    if comp_risk>max_comp_risk:
        comp_risk_overflow_flag = comp_risk
        comp_risk = max_comp_risk

    comp_risk /= max_comp_risk
    print("Norm comp_risk:",comp_risk)

    return comp_risk

def current_questions_responses_list(questions_list, responses_list, risk_area):
    
    current_questions_list = []
    current_responses_list = []

    ci=0
    for question in questions_list:
        print("Keys:",question['risk_areas'].keys(),"Risk Area:",risk_area,"\n")
        if risk_area in question['risk_areas'].keys():
            current_questions_list.append(question)
            current_responses_list.append(responses_list[ci])
        ci+=1

    return current_questions_list,current_responses_list 


def getPreBody(width, height, vendorid):
    pre_draw_risk_areas_png(vendorid)
    category = get_col_value(vendorid, 'Max Risk Service Category w/ Software LOB 1')

    global recommended_riq_questions
    col_value = ""
    
    vendor_row = risk_df_riq.loc[risk_df_riq["18 Digit ID"] == vendorid]
    
    if len(vendor_row.index)!=0:
        col_value = vendor_row['Recommended RIQ Questions'].iloc[0]

    recommended_riq_questions = [float(quest) for quest in col_value[1:-1].split(', ')]
    print(recommended_riq_questions,type(recommended_riq_questions))

    widthList = [
        width * 0.05,
        width * 0.9,
        width * 0.05
    ]

    heightList = [
        height * 0.04,
        height * 0.04,
        height * 0.03,
        height * -0.005,
        height * 0.5,
        height * 0.3,
        height * 0.09
    ]
    
    para0Style = ParagraphStyle('para0Style')
    para0Style.alignment = 4
    para0Style.fontSize = 14
    para0Style.fontName = 'Helvetica-Bold'
    para0 = Paragraph("Vendor Profile",
        para0Style
    )

    para1Style = ParagraphStyle('para1Style')
    para1Style.alignment = 4
    para1Style.fontSize = 12
    para1text = "This is our calculated inherent risk score based on the information you entered for this specific vendor. The calculation is based on a rule based approach and account for five different risk areas, including  operational, compliance, business, technology and data risk. The inherent risk score ranges from 0-1."
    para1 = Paragraph(para1text,
        para1Style
    )

    para2Style = ParagraphStyle('para2Style')
    para2Style.alignment = 1
    para2Style.fontSize = 10
    para2 = Paragraph("<br/><br/><br/><b>Third Party Name: " + str(vendorid) + "&nbsp;&nbsp;|&nbsp;&nbsp;Service Category: " + str(category) + "</b>",
        para2Style
    )

    para3Style = ParagraphStyle('para3Style')
    para3Style.alignment = 1
    para3Style.fontSize = 20
    para3Style.textColor = colors.HexColor("#FF0000")
    para3 = Paragraph("<br/><br/><br/><b>Tier Level = " + str(tier_level) + "</b>",
        para3Style
    )

    res = Table([
            ['',para0,''],
            ['',para1,''],
            ['',para2,''],
            ['',para3,''],
            ['',_getUpperBodyImages(heightList[4],widthList[1]),''],
            ['',_getLowerBodyImages(heightList[5],widthList[1]),''],
            []
        ],
        widthList,
        heightList
    )

    res.setStyle([
        #('GRID', (0,0), (-1,-1), 1, 'red'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ("LINEBELOW", (1, 0), (1, 0), 2, colors.HexColor('#808080'))
    ])
    
    return res

def getBody(width, height, vendorid, category, questions_list, responses_list, concentration_risk):

    draw_risk_areas_png(category, questions_list,responses_list,concentration_risk)

    widthList = [
        width * 0.05,
        width * 0.9,
        width * 0.05
    ]

    heightList = [
        height * 0.04,
        height * 0.04,
        height * 0.03,
        height * -0.005,
        height * 0.5,
        height * 0.3,
        height * 0.09
    ]
    
    para0Style = ParagraphStyle('para0Style')
    para0Style.alignment = 4
    para0Style.fontSize = 14
    para0Style.fontName = 'Helvetica-Bold'
    para0 = Paragraph("Vendor Profile",
        para0Style
    )

    para1Style = ParagraphStyle('para1Style')
    para1Style.alignment = 4
    para1Style.fontSize = 12
    para1text = "This is our calculated inherent risk score based on the information you entered for this specific vendor. The calculation is based on a rule based approach and account for five different risk areas, including  operational, compliance, business, technology and data risk. The inherent risk score ranges from 0-1."
    para1 = Paragraph(para1text,
        para1Style
    )

    para2Style = ParagraphStyle('para2Style')
    para2Style.alignment = 1
    para2Style.fontSize = 10
    para2 = Paragraph("<br/><br/><br/><b>Third Party Name: " + str(vendorid) + "&nbsp;&nbsp;|&nbsp;&nbsp;Service Category: " + str(category) + "</b>",
        para2Style
    )

    para3Style = ParagraphStyle('para3Style')
    para3Style.alignment = 1
    para3Style.fontSize = 20
    para3Style.textColor = colors.HexColor("#FF0000")
    para3 = Paragraph("<br/><br/><br/><b>Tier Level = " + str(tier_level) + "</b>",
        para3Style
    )

    res = Table([
            ['',para0,''],
            ['',para1,''],
            ['',para2,''],
            ['',para3,''],
            ['',_getUpperBodyImages(heightList[4],widthList[1]),''],
            ['',_getLowerBodyImages(heightList[5],widthList[1]),''],
            []
        ],
        widthList,
        heightList
    )

    res.setStyle([
        #('GRID', (0,0), (-1,-1), 1, 'red'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ("LINEBELOW", (1, 0), (1, 0), 2, colors.HexColor('#808080'))
    ])
    
    return res

def _getUpperBodyImages(height,width):
    
    widthList = [
        width * 0.5,
        width * 0.6
    ]

    positionPlot = Image(base_path+'resources/risk_position.png',widthList[0],height,kind='proportional')
    gaugePlot = Image(base_path+'resources/inherent_risk_gauge.png',widthList[1],height,kind='proportional')

    res = Table([
            [positionPlot,gaugePlot]
        ],
        widthList,
        height
    )
    
    res.setStyle([
        #('GRID', (0,0), (-1,-1), 1, 'red'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'CENTER'),
    ])

    return res

def _getLowerBodyImages(height,width):

    global recommended_riq_questions

    widthList = [
        width * 0.6,
        width * 0.4
    ]

    gaugePlot = Image(base_path+'resources/risk_areas.png',widthList[0],height,kind='proportional')


    paraL0Style = ParagraphStyle('paraL0Style')
    paraL0Style.alignment = 1
    paraL0Style.fontSize = 12
    paraL0Style.fontName = 'Helvetica-Bold'
    para0 = Paragraph("Recommended RIQ Parent Questions: " + str([int(quest) for quest in recommended_riq_questions])[1:-1],
        paraL0Style
    )

    recommended_riq_questions = []

    res = Table([
            [gaugePlot,para0]
        ],
        widthList,
        height * 0.5
    )
    
    res.setStyle([
        #('GRID', (0,0), (-1,-1), 1, 'red'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'CENTER'),
    ])

    return res

def _getUserTable(width, height, risk_area, start, end, questions_list, responses_list):

    heightList = [
        height * 0.2
    ]

    widthList = [
        width * 0.1,
        width * 0.5,
        width * 0.3,
        width * 0.1
    ]

    p00Style = ParagraphStyle('p00Style')
    p00Style.alignment = 1
    p00Style.fontSize = 6
    p01Style = ParagraphStyle('p01Style')
    p01Style.alignment = 1
    p01Style.fontSize = 6
    p02Style = ParagraphStyle('p02Style')
    p02Style.alignment = 1
    p02Style.fontSize = 6
    p03Style = ParagraphStyle('p03Style')
    p03Style.alignment = 1
    p03Style.fontSize = 6

    pi0Style = ParagraphStyle('pi0Style')
    pi0Style.alignment = 1
    pi0Style.fontSize = 6
    pi1Style = ParagraphStyle('pi1Style')
    pi1Style.alignment = 1
    pi1Style.fontSize = 6
    pi2Style = ParagraphStyle('pi2Style')
    pi2Style.alignment = 1
    pi2Style.fontSize = 6
    pi3Style = ParagraphStyle('pi3Style')
    pi3Style.alignment = 1
    pi3Style.fontSize = 6

    p00 = Paragraph('<b>S.No.</b>',p00Style)
    p01 = Paragraph('<b>Question</b>',p01Style)
    p02 = Paragraph('<b>Response</b>',p02Style)
    p03 = Paragraph('<b>Risk Score</b>',p03Style)

    plist = [
        [p00,p01,p02,p03]
    ]
    
    print("\n\nResponses List:",list(responses_list),"\n\n")
    
    current_questions_list, current_responses_list = current_questions_responses_list(questions_list,responses_list,risk_area)
    
    print("cql: ",current_questions_list)
    print("\ncrl: ",current_responses_list)

    if end == "all":
        end=len(current_questions_list)

    for i in range(start,end):
        print(i)
        question = current_questions_list[i]
        pi0 = Paragraph(str(i+1)+'.',pi0Style)
        pi1 = Paragraph(question['question'][:100] + "...",pi1Style)


        score=0
        risk_specific_responses_list = []
        for response in current_responses_list[i]:
            for li in question['risk_areas'][risk_area]:
                print("Response: ", response,"question: ",question['options'][li],"\n")
                if response == question['options'][li]:
                    risk_specific_responses_list.append(response)
                    score += question['scores'][li]
                    break

        pi2 = Paragraph(str(risk_specific_responses_list),pi2Style)
        pi3 = Paragraph(str(score),pi3Style)
        pi=[pi0,pi1,pi2,pi3]
        plist.append(pi)

        response_len = sum([len(res) for res in risk_specific_responses_list])
        print("\nResponse length:",sum([len(res) for res in risk_specific_responses_list]))
        heightList.append(max(height * 0.22, height * response_len * 0.17 * 0.012))


    res = Table(plist,
        widthList,
        heightList
    )

    res.setStyle([
        #('GRID', (0,0), (-1,-1), 1, 'red'),
        ('INNERGRID', (0,0), (-1,-1), 1, colors.HexColor('#ffffff')),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('TOPPADDING', (0, 0), (-1, -1), 15),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 15),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor("#f5f5f5"))
    ])

    return res

def _getOperationalRiskBody(width, height, questions_list, responses_list):
    
    heightList = [
        height * 0.12,
        height * 0.05,
        height * 0.83,
    ]

    paraL0Style = ParagraphStyle('paraL0Style')
    paraL0Style.alignment = 4
    paraL0Style.fontSize = 12
    paraL0Style.fontName = 'Helvetica-Bold'
    para0 = Paragraph("Operational Risk Responses",
        paraL0Style
    )

    res = Table([
            [para0],
            [],
            [_getUserTable(width,heightList[2],"operational",0,"all",questions_list,responses_list)]
        ],
        width,
        heightList
    )
    
    res.setStyle([
        #('GRID', (0,0), (-1,-1), 1, 'red'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('LEFTPADDING', (-1, -1), (-1, -1), 10),
        ('BOTTOMPADDING', (-1, -1), (-1, -1), 0),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'TOP')
    ])

    return res

def _getTechnologyRiskBody(width, height, questions_list, responses_list):
    
    heightList = [
        height * 0.12,
        height * 0.05,
        height * 0.83,
    ]

    paraL0Style = ParagraphStyle('paraL0Style')
    paraL0Style.alignment = 4
    paraL0Style.fontSize = 12
    paraL0Style.fontName = 'Helvetica-Bold'
    para0 = Paragraph("Technology Risk Responses",
        paraL0Style
    )

    res = Table([
            [para0],
            [],
            [_getUserTable(width,heightList[2],"technology",0,"all",questions_list,responses_list)]
        ],
        width,
        heightList
    )
    
    res.setStyle([
        #('GRID', (0,0), (-1,-1), 1, 'red'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('LEFTPADDING', (-1, -1), (-1, -1), 10),
        ('BOTTOMPADDING', (-1, -1), (-1, -1), 0),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'TOP')
    ])

    return res

def _getComplianceRiskBody(width, height, questions_list, responses_list):
    
    heightList = [
        height * 0.12,
        height * 0.05,
        height * 0.83,
    ]

    paraL0Style = ParagraphStyle('paraL0Style')
    paraL0Style.alignment = 4
    paraL0Style.fontSize = 12
    paraL0Style.fontName = 'Helvetica-Bold'
    para0 = Paragraph("Compliance Risk Responses",
        paraL0Style
    )

    res = Table([
            [para0],
            [],
            [_getUserTable(width,heightList[2],"compliance",0,"all",questions_list,responses_list)]
        ],
        width,
        heightList
    )
    
    res.setStyle([
        #('GRID', (0,0), (-1,-1), 1, 'red'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('LEFTPADDING', (-1, -1), (-1, -1), 10),
        ('BOTTOMPADDING', (-1, -1), (-1, -1), 0),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'TOP')
    ])

    return res

def _getBusinessRiskBody(width, height, questions_list, responses_list):
    
    heightList = [
        height * 0.12,
        height * 0.05,
        height * 0.83,
    ]

    paraL0Style = ParagraphStyle('paraL0Style')
    paraL0Style.alignment = 4
    paraL0Style.fontSize = 12
    paraL0Style.fontName = 'Helvetica-Bold'
    para0 = Paragraph("Business Risk Responses",
        paraL0Style
    )

    res = Table([
            [para0],
            [],
            [_getUserTable(width,heightList[2],"business",0,"all",questions_list,responses_list)]
        ],
        width,
        heightList
    )
    
    res.setStyle([
        #('GRID', (0,0), (-1,-1), 1, 'red'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('LEFTPADDING', (-1, -1), (-1, -1), 10),
        ('BOTTOMPADDING', (-1, -1), (-1, -1), 0),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'TOP')
    ])

    return res

def _getDataRiskBody(width, height, questions_list, responses_list):
    
    heightList = [
        height * 0.12,
        height * 0.05,
        height * 0.83,
    ]

    paraL0Style = ParagraphStyle('paraL0Style')
    paraL0Style.alignment = 4
    paraL0Style.fontSize = 12
    paraL0Style.fontName = 'Helvetica-Bold'
    para0 = Paragraph("Data Risk Responses",
        paraL0Style
    )

    res = Table([
            [para0],
            [],
            [_getUserTable(width,heightList[2],"data",0,"all",questions_list,responses_list)]
        ],
        width,
        heightList
    )
    
    res.setStyle([
        #('GRID', (0,0), (-1,-1), 1, 'red'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('LEFTPADDING', (-1, -1), (-1, -1), 10),
        ('BOTTOMPADDING', (-1, -1), (-1, -1), 0),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'TOP')
    ])

    return res    

def getPage2Body(width, height, questions_list, responses_list):

    widthList = [
        width * 0.1,
        width * 0.8,
        width * 0.1
    ]

    heightList = [
        height * 0.05,
        height * 0.25,
        height * 0.18,
        height * 0.20,
        height * 0.22,
    ]

    print("Heights:",heightList)

    headpara0Style = ParagraphStyle('headpara0Style')
    headpara0Style.alignment = 4
    headpara0Style.fontSize = 14
    headpara0Style.fontName = 'Helvetica-Bold'
    headpara0 = Paragraph("Appendix",
        headpara0Style
    )

    res = Table([
            ['',headpara0,''],
            ['',_getOperationalRiskBody(widthList[1],heightList[1],questions_list,responses_list),''],
            ['','',''],
            ['',_getTechnologyRiskBody(widthList[1],heightList[3],questions_list,responses_list),''],
            ['',_getComplianceRiskBody(widthList[1],heightList[4],questions_list,responses_list),''],
        ],
        widthList,
        heightList,
    )

    res.setStyle([
        #('GRID', (0,0), (-1,-1), 1, 'red'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ("LINEBELOW", (1, 0), (1, 0), 2, colors.HexColor('#808080'))
    ])

    return res

def getPage3Body(width, height, questions_list, responses_list):

    widthList = [
        width * 0.1,
        width * 0.8,
        width * 0.1
    ]

    heightList = [
        height * 0.05,
        height * 0.25,
        height * 0.05,
        height * 0.3,
    ]

    print("Heights:",heightList)

    headpara0Style = ParagraphStyle('headpara0Style')
    headpara0Style.alignment = 4
    headpara0Style.fontSize = 14
    headpara0Style.fontName = 'Helvetica-Bold'
    headpara0 = Paragraph("Appendix",
        headpara0Style
    )

    res = Table([
            ['',headpara0,''],
            ['',_getBusinessRiskBody(widthList[1],heightList[1],questions_list,responses_list),''],
            ['','',''],
            ['',_getDataRiskBody(widthList[1],heightList[3],questions_list,responses_list),''],
        ],
        widthList,
        heightList,
    )

    res.setStyle([
        #('GRID', (0,0), (-1,-1), 1, 'red'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ("LINEBELOW", (1, 0), (1, 0), 2, colors.HexColor('#808080'))
    ])

    return res