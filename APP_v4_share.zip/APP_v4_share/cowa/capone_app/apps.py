from django.apps import AppConfig


class CaponeAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'capone_app'
