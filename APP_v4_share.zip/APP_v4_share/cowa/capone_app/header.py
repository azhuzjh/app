from reportlab.platypus import Table, Image, Paragraph
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
import os

base_path = str(os.path.abspath(os.path.dirname(__name__))) + "/capone_app/"

def getHeader(width, height,):

    widthList = [
        width * 0.15,
        width * 0.7,
        width * 0.15
    ]

    heightList = [
        # height * 0.7,
        height * 1,
    ]

    headStyle = ParagraphStyle("headStyle")
    headStyle.fontSize = 18
    headStyle.alignment = 1
    headStyle.textColor = colors.HexColor("#191970")

    headPara = Paragraph("Risk Report",headStyle)

    res = Table([
            # ['',_getLogo(widthList[1], heightList[0]),''],
            ['',headPara,''],
        ],
        widthList,
        heightList,
    )

    res.setStyle([
        #('GRID', (0,0), (-1,-1), 1, 'red'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
    ])

    return res

def _getLogo(width, height):

    widthList = [
        width * 0.4,
        width * 0.2,
        width * 0.4
    ]

    heightList = [
        height * 0.3,
        height * 0.6,
    ]

    emptyStyle = ParagraphStyle("emptyStyle")
    emptyStyle.fontSize = 6
    
    emptyPara = Paragraph("",emptyStyle)
    
    kpmgLogo = Image(base_path+'resources/kpmgLogo.png',widthList[0],heightList[1])
    
    crossStyle = ParagraphStyle("crossStyle")
    crossStyle.fontSize = 40
    crossStyle.alignment = 1
    crossStyle.leading = 45

    cross = Paragraph("X",crossStyle)
    
    capOneLogo = Image(base_path+'resources/capOneLogo.png',widthList[2],heightList[1])

    tableList = [
        [emptyPara,emptyPara,emptyPara],
        [capOneLogo,cross,kpmgLogo],
    ]

    res = Table(tableList,widthList,heightList)
    
    res.setStyle([
        #('GRID', (0,0), (-1,-1), 1, 'blue'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ("LINEBELOW", (0, -1), (-1, -1), 2, colors.HexColor('#808080'))
    ])

    return res