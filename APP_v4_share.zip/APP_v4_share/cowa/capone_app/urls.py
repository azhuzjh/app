from django.urls import path

from . import views

app_name = 'capone_app'

urlpatterns = [
    path('', views.index, name='index'),
    path('overall_landscape', views.overall_landscape, name='overall_landscape'),
    path('category_summary/<str:category>', views.category_summary, name='category_summary'),
    path('search_vendor', views.search_vendor, name='search_vendor'),
    path('vendor_page/', views.vendor_page, name='vendor_page'),
    path('vendor_report/', views.vendor_report, name='vendor_report'),
    path('new_vendor', views.new_vendor, name='new_vendor'),
    path('new_vendor_categorized/<str:vendorid>/<str:category>', views.new_vendor_categorized, name='new_vendor_categorized'),
    path('prioritized_vendor_list', views.prioritized_vendor_list, name='prioritized_vendor_list'),
    path('prioritized_vendor_list/<int:vendor_count>', views.prioritized_vendor_list, name='prioritized_vendor_list'),
    path('modeling_description', views.modeling_description, name='modeling_description'),    
]